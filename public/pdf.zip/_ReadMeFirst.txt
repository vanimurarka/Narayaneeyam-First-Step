Dear Reader,

To use all the files in an integrated manner, open "_Index.html" in your browser. It contains links to all the Dashakas and other files in an easy to use manner.

This folder, zip file, contains the whole Narayaneeyam and its translated explanation in English. Files containing an introduction and a write-up about this initiative are also given. 

It is our request, that if you share/distribute these files with others (you are most welcome to do so!), please share all the files together as one zip, rather than sharing some specific Dashakas only.

Thank you

Asha Murarka
